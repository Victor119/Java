public class FlourPacker {
    public static void main(String[] args) {
        System.out.println(canPack(0,5,4));
    }
    public static boolean canPack(int bigCount, int smallCount, int goal) {
        if (bigCount < 0 || smallCount < 0 || goal < 0 || (bigCount == 0 && smallCount < goal)){
            return false;
        }
        else if((bigCount==0) && (smallCount>goal)) {
            return true;
        }
        else {
            for(int i=1; i<bigCount+1; i++){
                goal = goal -5;
            }
            if(goal==0)
                return true;
            else {
                if(goal<0){
                    return false;
                }
                else {
                    for(int i=1; i<smallCount+1; i++)
                        goal = goal -1 ;
                    if(goal==0)
                        return true;
                    else
                        return false;
                }
            }
        }
    }
}
