import java.util.ArrayList;

public class MobilePhone {
    private ArrayList<Contacts> contacts;
}
