public class Challange {
    //Challange video - 49
    public static void main(String args[]) {
        String name = "albert";
        int highscore = calculateHighScorePosition(1500);
        displayHighScorePosition(name, highscore );

        name = "andrei";
        highscore = calculateHighScorePosition(900);
        displayHighScorePosition(name, highscore );

        name = "victor";
        highscore = calculateHighScorePosition(400);
        displayHighScorePosition(name, highscore );

        name = "ambrozie";
        highscore = calculateHighScorePosition(50);
        displayHighScorePosition(name, highscore );
    }
    public static void displayHighScorePosition(String name,int position){
        System.out.println(name + " managed to get into position " + position + " on the high score table");
    }
    public static int calculateHighScorePosition(int score){
        if ( score >= 1000) {
            return 1;
        }
        else if ( score >= 500){
            return 2;
        }
        else if ( score >= 100){
            return 3;
        }
        return 4;
    }
}
