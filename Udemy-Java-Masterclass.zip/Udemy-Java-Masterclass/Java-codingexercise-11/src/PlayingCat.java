public class PlayingCat {
    public static void main(String[] args) {
        System.out.println(isCatPlaying(true,10));
    }
    public static boolean isCatPlaying(boolean summer, int temperature){
        if(summer){
            if((temperature > 24) && (temperature <= 45)){
                return true;
            }
            else
                return false;
        }
        else{
            if((temperature > 24) && (temperature <= 35)){
                return true;
            }
            else
                return false;
        }
    }
}
