public class SharedDigit {
    public static void main(String[] args) {
        System.out.println(hasSharedDigit(19,99));
    }

    public static boolean hasSharedDigit(int number_1,int number_2){
        int ok = 0;
        if((number_1 < 10 || number_1 > 99) || (number_2 < 10 || number_2 > 99)){
            return false;
        }
        else{
            while(number_1!=0 && (ok == 0)){
                int duplicate = number_2;
                while (duplicate != 0 && (ok == 0)) {
                    if ((number_1 % 10) == (duplicate%10)) {
                        ok++;
                    }
                    duplicate = duplicate / 10;
                }
                number_1 = number_1/10;
            }
        }
        if(ok != 0)
            return true;
        else
            return false;
    }
}
