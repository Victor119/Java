public class LeapYear {
    public static void main(String[] args) {
        System.out.println(isLeapYear(1944));
    }
    public static boolean isLeapYear(int bis){
        if ( bis <= 0 || bis > 9999)
            return false;
        else{
            if(bis % 4 == 0 && (bis % 100 !=0))
                return true;
            if(bis % 400 == 0)
                return true;
            return false;
        }
    }
}
