public class PerfectNumber {
    public static void main(String[] args) {
        System.out.println(isPerfectNumber(6));
    }

    public static boolean isPerfectNumber(int number){
        if(number<1)
            return false;
        else{
            int copy = number;
            while(number != 0 && number!=-1){
                for(int i=1; i<=copy/2; i++){
                    if(copy%i == 0)
                        number = number - i;
                }
                if(number!=0)
                    number = -1;
            }
            if(number == 0)
                return true;
            else
                return false;
        }
    }
}
