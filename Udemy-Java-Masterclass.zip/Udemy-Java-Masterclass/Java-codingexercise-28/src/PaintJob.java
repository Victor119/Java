import javax.swing.*;

public class PaintJob {
    public static void main(String[] args) {
        System.out.println(getBucketCount(3.4,2.1,1.5,2));
        System.out.println(getBucketCount(3.4,2.1,1.5));
        System.out.println(getBucketCount(3.26,0.75));
    }
    public static int getBucketCount(double width, double height, double areaPerBucket, int extraBuckets){
        int i = 0;
        double area = width*height;
        if(width<0.000001|| height<0.00001 || areaPerBucket<0.000001 || extraBuckets<0){
            return -1;
        }
        else {
            if(area - (double)(areaPerBucket*extraBuckets) <=0d) {
                return 0;
            }
            else {
                area = area - (double)(areaPerBucket*extraBuckets);
                while(area>0d){
                    area = area - areaPerBucket;
                    i++;
                }
                return i;
            }
        }
    }
    public static int getBucketCount(double width,double height,double areaPerBucket){
        int i=0;
        double area = width*height;
        if(width<0.00001 || height<0.00001 || areaPerBucket<0.00001){
            return -1;
        }
        else{
            while(area>0d){
                area = area - areaPerBucket;
                i++;
            }
            return i;
        }
    }
    public static int getBucketCount(double area,double areaPerBucket){
        int i=0;
        if(area<0.00001 || areaPerBucket<0.00001){
            return -1;
        }
        else {
            while(area>0){
                area = area - areaPerBucket;
                i++;
            }
            return i;
        }
    }
}
