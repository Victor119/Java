

/**
 * Class FeedBack
 */
public class FeedBack {

  //
  // Fields
  //

  private String nume;
  private String prenume;
  
  //
  // Constructors
  //
  public FeedBack () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of nume
   * @param newVar the new value of nume
   */
  private void setNume (String newVar) {
    nume = newVar;
  }

  /**
   * Get the value of nume
   * @return the value of nume
   */
  private String getNume () {
    return nume;
  }

  /**
   * Set the value of prenume
   * @param newVar the new value of prenume
   */
  private void setPrenume (String newVar) {
    prenume = newVar;
  }

  /**
   * Get the value of prenume
   * @return the value of prenume
   */
  private String getPrenume () {
    return prenume;
  }

  //
  // Other methods
  //

  /**
   * @return       String
   */
  public String getNume()
  {
  }


  /**
   * @return       String
   */
  public String getPrenume()
  {
  }


  /**
   */
  public void setNume()
  {
  }


  /**
   */
  public void setPrenume()
  {
  }


}
