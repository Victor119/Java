

/**
 * Class Persoana
 */
public class Persoana {

  //
  // Fields
  //

  private String nume;
  private int CNP;
  private String emai;
  
  //
  // Constructors
  //
  public Persoana () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of nume
   * @param newVar the new value of nume
   */
  private void setNume (String newVar) {
    nume = newVar;
  }

  /**
   * Get the value of nume
   * @return the value of nume
   */
  private String getNume () {
    return nume;
  }

  /**
   * Set the value of CNP
   * @param newVar the new value of CNP
   */
  private void setCNP (int newVar) {
    CNP = newVar;
  }

  /**
   * Get the value of CNP
   * @return the value of CNP
   */
  private int getCNP () {
    return CNP;
  }

  /**
   * Set the value of emai
   * @param newVar the new value of emai
   */
  private void setEmai (String newVar) {
    emai = newVar;
  }

  /**
   * Get the value of emai
   * @return the value of emai
   */
  private String getEmai () {
    return emai;
  }

  //
  // Other methods
  //

  /**
   * @return       int
   */
  public int checkEmail()
  {
  }


}
