

/**
 * Class ExceptiiFeedBack
 */
public class ExceptiiFeedBack extends FeedBack {

  //
  // Fields
  //

  private String exceptie;
  
  //
  // Constructors
  //
  public ExceptiiFeedBack () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of exceptie
   * @param newVar the new value of exceptie
   */
  private void setExceptie (String newVar) {
    exceptie = newVar;
  }

  /**
   * Get the value of exceptie
   * @return the value of exceptie
   */
  private String getExceptie () {
    return exceptie;
  }

  //
  // Other methods
  //

  /**
   */
  public void getExceptie()
  {
  }


  /**
   */
  public void setExceptie()
  {
  }


}
