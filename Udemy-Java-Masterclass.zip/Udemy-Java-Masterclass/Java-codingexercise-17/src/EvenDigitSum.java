public class EvenDigitSum {
    public static void main(String[] args) {
        System.out.println(getEvenDigitSum(1249));
    }

    public static int getEvenDigitSum(int number){
        int sum = 0, duplicate = number;
        if( number < 0)
            return -1;
        else {
            while (duplicate != 0){
                if( (duplicate%10)%2 ==0){
                    sum = sum + duplicate%10;
                }
                duplicate = duplicate/10;
            }
        }
        return sum;
    }
}
