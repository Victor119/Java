import java.util.Scanner;

public class First {
    public static void main(String[] args) {
        int x;
        int[] intArray = new int[6];
        Scanner scanner = new Scanner(System.in);

        intArray= getIntegers(5);
        print(sortIntegers(intArray));
    }
    public static int[] sortIntegers(int[]  intArray){
        for(int i=0; i<intArray.length; i++){
            for (int j=0; j<intArray.length; j++){
                if(intArray[i] > intArray[j]){
                    int x = intArray[i];
                    intArray[i] = intArray[j];
                    intArray[j] = x;
                }
            }
        }
        return intArray;
    }
    public static int[] getIntegers(int number){
        int[] myIntArray = new int[number];
        Scanner scanner = new Scanner(System.in);

        for (int i=0; i<myIntArray.length; i++){
            myIntArray[i] = scanner.nextInt();
        }
        return myIntArray;
    }
    public static void print(int[] array){
        for(int i=0; i< array.length; i++){
            System.out.println("Element " + i + " contents " + array[i]);
        }
    }
}
