import java.util.ArrayList;
import java.util.List;

public class Player implements ISaveable {
    private String name;
    private String weapon;
    private int hitPoints;
    private int strenght;

    public Player(String name,int hitPoints,int strenght){
        this.name = name;
        this.weapon = "Sword";
        this.hitPoints = hitPoints;
        this.strenght = strenght;
    }

    public String getName() {
        return name;
    }

    public String getWeapon() {
        return weapon;
    }

    public int getHitPoints() {
        return hitPoints;
    }

    public int getStrenght() {
        return strenght;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setWeapon(String weapon) {
        this.weapon = weapon;
    }

    public void setHitPoints(int hitPoints) {
        this.hitPoints = hitPoints;
    }

    public void setStrenght(int strenght) {
        this.strenght = strenght;
    }

    @Override
    public List<String> write(){
        List<String> list = new ArrayList<String>();
        list.add(name);
        list.add(weapon);
        list.add(String.valueOf(hitPoints));
        list.add(String.valueOf(strenght));
        return list;
    }

    @Override
    public List<String> read(){
        List<String> list = new ArrayList<String>();
        list.add(0,name);
        list.add(1,weapon);
        list.add(2,String.valueOf(hitPoints));
        list.add(3,String.valueOf(strenght));
        return list;
    }

    @Override
    public String toString(){
        String string;
        string = "Player{name ='" + this.name + "', hitPoints =" + this.hitPoints + ", strenght=" + this.strenght + ", weapon='" + this.weapon + "'}";
        return string;
    }
}
