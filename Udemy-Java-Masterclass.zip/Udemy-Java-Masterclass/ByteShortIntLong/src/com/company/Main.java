package com.company;

public class Main {

    public static void main(String[] args) {
	//Challange Video 28 Java Masterclass udemy
        // Creaza o variabila byte si da-i un byte number
        // Creeaza o varibila de tip short si dai un numar adecvat de tip short
        // Creeza o variabila de tip int  si dai un numar adecvat de tip int
        // Creeaza o variabila de tip long care are valoarea 50000 plus 10 ori suma dintre variabilele byte , short si int
        byte myByteNumber = 10;
        short myShortNumber = 20;
        int myIntNumber = 30;
        int myTotal = (int) (myByteNumber + myIntNumber + myShortNumber);
        long myLongNumber = 50000L + 10L * myTotal;
        System.out.println(myLongNumber);
        //Challange video 29
        // Converteste un anumit numar de pounds in kilograme
        double myPoundnumber = 22d;
        double myKilogramnumber = myPoundnumber / 2.20462d;
        System.out.println(myKilogramnumber);
    }
}
