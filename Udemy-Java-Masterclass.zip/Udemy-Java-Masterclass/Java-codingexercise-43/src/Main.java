import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int[] myArray = {5,4,3,2,1};
        reverse(myArray);
    }
    private static void reverse(int[] array){
        System.out.println("Array = " + Arrays.toString(array));
        for(int i=0; i<array.length/2; i++){
            int x=array[array.length-1-i];
            array[array.length-1-i] = array[i];
            array[i] = x;
        }
        System.out.println("Reversed Array = " + Arrays.toString(array));
    }
}
