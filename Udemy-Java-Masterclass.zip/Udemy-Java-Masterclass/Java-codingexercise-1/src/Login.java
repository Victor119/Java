

/**
 * Class Login
 */
public class Login extends FeedBack {

  //
  // Fields
  //

  private String nume;
  private String password;
  
  //
  // Constructors
  //
  public Login () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of nume
   * @param newVar the new value of nume
   */
  private void setNume (String newVar) {
    nume = newVar;
  }

  /**
   * Get the value of nume
   * @return the value of nume
   */
  private String getNume () {
    return nume;
  }

  /**
   * Set the value of password
   * @param newVar the new value of password
   */
  private void setPassword (String newVar) {
    password = newVar;
  }

  /**
   * Get the value of password
   * @return the value of password
   */
  private String getPassword () {
    return password;
  }

  //
  // Other methods
  //

  /**
   */
  public void login()
  {
  }


}
