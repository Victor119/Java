

/**
 * Class utilizator
 */
public class utilizator {

  //
  // Fields
  //

  private String nume;
  
  //
  // Constructors
  //
  public utilizator () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of nume
   * @param newVar the new value of nume
   */
  private void setNume (String newVar) {
    nume = newVar;
  }

  /**
   * Get the value of nume
   * @return the value of nume
   */
  private String getNume () {
    return nume;
  }

  //
  // Other methods
  //

  /**
   */


}
