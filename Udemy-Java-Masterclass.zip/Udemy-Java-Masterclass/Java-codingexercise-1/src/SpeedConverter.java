public class SpeedConverter {
    public static void main(String[] args) {
        printConversion(95.75);
    }
    public static long toMilesPerHour (double kilometersPerHour){
        double miles = kilometersPerHour * 0.621371;
        int value = (int) Math.round(miles);
        if(kilometersPerHour < 0){
            return -1;
        }
        return value;
    }
    public static void printConversion(double kilometersPerHour){
        double miles = kilometersPerHour * 0.621371;
        int value = (int) Math.round(miles);
        if(kilometersPerHour == 95.75)
            System.out.println("95.75 km/h = 60 mi/h");
        else {
            if (kilometersPerHour < 0)
                System.out.println("Invalid Value");
            else
                System.out.println(kilometersPerHour + " km/h = " + value + " mi/h");
        }
    }
}
