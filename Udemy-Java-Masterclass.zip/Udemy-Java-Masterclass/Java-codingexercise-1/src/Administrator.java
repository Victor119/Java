

/**
 * Class Administrator
 */
public class Administrator {

  //
  // Fields
  //

  private String nume;
  private String email;
  
  //
  // Constructors
  //
  public Administrator () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of nume
   * @param newVar the new value of nume
   */
  private void setNume (String newVar) {
    nume = newVar;
  }

  /**
   * Get the value of nume
   * @return the value of nume
   */
  private String getNume () {
    return nume;
  }

  /**
   * Set the value of email
   * @param newVar the new value of email
   */
  private void setEmail (String newVar) {
    email = newVar;
  }

  /**
   * Get the value of email
   * @return the value of email
   */
  private String getEmail () {
    return email;
  }

  //
  // Other methods
  //

  /**
   */
  public void getName()
  {
  }


  /**
   * @return       int
   */
  public int checkEmail(String email)
  {
      if(this.email.isEmpty()){
        return 0;
      }else{
        return 1;
      }
  }


}
