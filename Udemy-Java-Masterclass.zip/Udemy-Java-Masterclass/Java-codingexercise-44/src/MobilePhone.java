import java.util.ArrayList;

public class MobilePhone {
    private String myNumber;
    private ArrayList<Contact> myContact;

    public MobilePhone(String myNumber, Contact contact){
        this.myNumber = myNumber;
        this.myContact = new ArrayList<Contact>();
    }
    public boolean addNewContact(Contact contact){
        int item = findContact(contact);
        if(item < 0){
            return true;
        }
        else {
            return  false;
        }
    }
    public boolean updateContact(Contact contactOld,Contact contactNew){
        int pozitie = findContact(contactOld);
        if(pozitie<0){
            return false;
        }
        this.myContact.set(pozitie,contactNew);
        return true;
    }
    public boolean removeContact(Contact contact){
        int pozitie = findContact(contact);
        if(pozitie<0){
            return false;
        }
        else {
            this.myContact.remove(pozitie);
            return true;
        }
    }
    public Contact queryContact(String name){
        for (int i=0; i<this.myContact.size(); i++){
            Contact item = this.myContact.get(i);
            if(item.getName().equals(name)){
                return new Contact(item.getName(),item.getPhoneNumber());
            }
        }
        return null;
    }
    private int findContact(Contact contact){
        return this.myContact.indexOf(contact);
    }
    private int findContact(String number){
        return this.myContact.indexOf(number);
    }
    private void printContacts(){
        for(int i=0; i<myContact.size(); i++){
            System.out.println(myContact.get(i));
        }
    }
}
