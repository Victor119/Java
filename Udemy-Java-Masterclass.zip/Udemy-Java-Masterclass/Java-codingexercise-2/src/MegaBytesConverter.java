public class MegaBytesConverter {
    public static void main(String[] args) {
        printMegaBytesAndKiloBytes(-3);
    }
    public static void printMegaBytesAndKiloBytes(int kiloBytes){
        int newKilobyte = kiloBytes/1024, Mb = (int) Math.round(newKilobyte), Kb = (int) Math.round(kiloBytes % 1024);
        if( kiloBytes < 0)
            System.out.println("Invalid Value");
        else
            System.out.println(kiloBytes + " KB = " + Mb + " MB and " + Kb + " KB");
    }
}
