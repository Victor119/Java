import java.security.Signature;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class Album {
    private String name;
    private String artist;
    private ArrayList<Song> songs;

    public Album(String album,String name){
        this.name = album;
        this.artist = name;
        this.songs = new ArrayList<Song>();
    }
    public boolean addSong(String title,double duration){
        if(findSong(title) == null){
            this.songs.add(new Song(title,duration));
            return true;
        }
        else {
            return false;
        }
    }
    private Song findSong(String title){
        for(int i=0; i < this.songs.size(); i++){
            if(this.songs.get(i).getTitle().equals(title)){
                return this.songs.get(i);
            }
        }
        return null;
    }
    public boolean addToPlayList(String title, LinkedList<Song> playList){
        Song checkSong = findSong(title);
        if(checkSong != null){
            playList.add(checkSong);
            return true;
        }
        return false;
    }
    public boolean addToPlayList(int track, LinkedList<Song> playList){
        int i= track - 1;
        if((i>=0) && (i <= this.songs.size())){
            playList.add(this.songs.get(i));
            return true;
        }
        return false;
    }

}
