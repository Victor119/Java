public class MinutesToYearsDaysCalculator {
    public static void main(String[] args) {
        printYearsAndDays(561600);
    }
    public static void printYearsAndDays(long minutes){
        long rest_ani, zile = minutes/60/24, ani = zile/60/365;
        if(minutes < 0)
            System.out.println("Invalid Value");
        else{
            rest_ani = zile/365;
            zile = zile%365;
            ani = ani + rest_ani;
            System.out.println(minutes + " min = " + ani + " y" + " and " + zile + " d");
        }
    }
}
