import java.util.Scanner;

public class First {
    public static void main(String[] args) {
        int count = scanner.nextInt();
        int[] myArray = new int[count];
        myArray = readElements(count);
        System.out.println(findMin(myArray));

    }
    public static int readIntegers(){
        Scanner scanner = new Scanner(System.in);
        int count = scanner.nextInt();
        return count;
    }
    public static int[] readElements(int count){
        int[] myIntArray = new int[count];
        Scanner scanner = new Scanner(System.in);

        for (int i=0; i<myIntArray.length; i++){
            myIntArray[i] = scanner.nextInt();
        }
        return myIntArray;
    }
    public static int findMin(int[] array){
        int min= Integer.MAX_VALUE;

        for(int i=0; i<array.length; i++){
            if(min>array[i])
                min = array[i];
        }
        return min;
    }
}
