public class vipCustomer {
    private double creditLimit;
    private String name;
    private String emailAddress;
    public vipCustomer(){
        this("Default name", 5000.0, "Default@email.com"); // cheama al 3-lea constructor
    }

    public vipCustomer(double creditLimit, String name) {
        this(name, creditLimit, "Default@email.com");
    }

    public vipCustomer(double creditLimit, String name, String emailAddress) {
        this.creditLimit = creditLimit;
        this.name = name;
        this.emailAddress = emailAddress;
    }

    public
}
