public class NumberPalindrome {
    public static void main(String[] args) {
        System.out.println(isPalindrome(-1221));
    }

    public static boolean isPalindrome(int number){
        int duplicate = number, palindrom = 0;
        if(number < 0) {
            number = number * -1;
            duplicate = duplicate * -1;
        }
        while(duplicate != 0){
            palindrom = palindrom + duplicate%10;
            palindrom = palindrom * 10;
            duplicate = duplicate/10;
        }
        palindrom = palindrom / 10;
        if(palindrom == number)
            return true;
        else
            return false;
    }
}
