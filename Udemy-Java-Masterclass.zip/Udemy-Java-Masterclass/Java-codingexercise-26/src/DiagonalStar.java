public class DiagonalStar {
    public static void main(String[] args) {
        printSquareStar(8);
    }

    public static void printSquareStar(int number){
        if(number<5)
            System.out.println("Invalid Value");
        else {
            for(int i=1; i<number+1 ; i++){
                for (int j=1; j<number+1; j++){
                    if(j==1 || j==number || i==1 || i==number){
                        System.out.print("*");
                    }
                    else {
                        if(i==j || (i+j-1 == number)){
                            System.out.print("*");
                        }
                        else {
                            System.out.print(" ");
                        }
                    }
                    if(j==number)
                        System.out.println();
                }
            }
        }
    }
}
