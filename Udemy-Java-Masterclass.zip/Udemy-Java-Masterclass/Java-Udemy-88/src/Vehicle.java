public class Vehicle {
    public Vehicle(){

    }
}
