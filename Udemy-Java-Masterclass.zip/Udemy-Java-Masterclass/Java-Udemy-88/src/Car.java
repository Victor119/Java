public class Car extends Vehicle {

}
