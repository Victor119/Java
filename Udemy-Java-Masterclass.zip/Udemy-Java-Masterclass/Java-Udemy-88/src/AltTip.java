public class AltTip extends Car {
}
