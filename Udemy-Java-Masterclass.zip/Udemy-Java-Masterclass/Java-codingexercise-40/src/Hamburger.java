public class Hamburger {
    private double price;

    public String addition1Name;
    public String addition2Name;
    public String addition3Name;
    public String addition4Name;
    public double addition1Price;
    public double addition2Price;
    public double addition3Price;
    public double addition4Price;

    public Hamburger(String name,String meat,double price,String breadRollType){
        this.price = price;
    }

    public void addHamburgerAddition1(String addition1Name,double addition1Price){
        this.price = this.price + addition1Price;
    }
    public void addHamburgerAddition2(String addition2Name,double addition2Price){
        this.price = this.price + addition2Price;
    }
    public void addHamburgerAddition3(String addition3Name,double addition3Price){
        this.price = this.price + addition3Price;
    }
    public void addHamburgerAddition4(String addition4Name,double addition4Price){
        this.price = this.price + addition4Price;
    }
    public double itemizehamburger(){
        return this.price;
    }
}
