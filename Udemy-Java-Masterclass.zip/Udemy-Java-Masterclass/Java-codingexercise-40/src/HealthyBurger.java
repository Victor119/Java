public class HealthyBurger extends Hamburger {
    private String healthyExtra1Name;
    private String healthyExtra2Name;
    private double healthyExtra1Price;
    private double healthyExtra2Price;

    public HealthyBurger(String meat,double price){
        super("",meat,price,"");

    }
    public void addHealthyAddition1(String healthyExtra1Name,double price){
        this.healthyExtra1Price = this.healthyExtra1Price + price;
        this.healthyExtra1Name = healthyExtra1Name;
    }
    public void addHealthyAddition2(String healthyExtra2Name,double price){
        this.healthyExtra2Price = this.healthyExtra2Price + price;
        this.healthyExtra2Name = healthyExtra2Name;
    }
    @Override
    public double itemizeHamburger(){
        System.out.println("Healthy hamburger on a Brown rye roll with " + super. + " " + super.itemizehamburger());
        System.out.println("Added " + this.healthyExtra1Name + " for an extra " + this.healthyExtra1Price);
        System.out.println("Added " + this.healthyExtra2Name + " for an extra " + this.healthyExtra2Price);
    }
}
