public class EqualSumChecker {
    public static void main(String[] args) {
        System.out.println(hasEqualSum(1,2,3));
    }
    public static boolean hasEqualSum(int number1,int number2, int total){
        if((number1 + number2) == total)
            return true;
        else
            return false;
    }
}
