public class GreatestCommonDivisor {
    public static void main(String[] args) {
        System.out.println(getGreatestCommonDivisor(12,30));
    }

    public static int getGreatestCommonDivisor(int first, int second){
        if( first<10 || second<10)
            return -1;
        else {
            if(first > second){
                int x= first;
                first = second;
                second =x ;
            }
            for(int i=second; i >= 2; i--)
            {
                if(first%i==0 && second%i==0) {
                    return i;
                }
            }
            return -1;
        }
    }
}
