public class First {
    public static void main(String[] args) {
        boolean valueBool = true;
        double firstDoublevalue = 20.00d, secondDoublevalue = 80.00d, thirdDoublevalue = 100d * (firstDoublevalue + secondDoublevalue), remainder = thirdDoublevalue % 40.00d;
        System.out.println("Suma double = " + thirdDoublevalue);
        System.out.println("Valoare remainder = " + remainder);
        if( remainder == 0){
            valueBool = false;
        }
        System.out.println("value of valueBool = " + valueBool);
        if (!valueBool){
            System.out.println("Got some remainder" );
        }
    }
}
