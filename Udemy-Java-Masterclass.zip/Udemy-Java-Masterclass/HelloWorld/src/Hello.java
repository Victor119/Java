public class Hello {

    public static void main(String[] args){
        System.out.println("Hello Victor");


        int myFirstnumber = (10 + 5) + (2 * 10);
        int mySecondNumber = 12;
        int myThirdNumber = myFirstnumber * 2;
        int myTotal = myFirstnumber + mySecondNumber + myThirdNumber;
        int myLastOne = 1000 - myTotal;
        System.out.println(myLastOne);
        System.out.println(myTotal);

        //Chalange section 24
        // Declare 2 variabile si adaugale la programul nostru
        // Prima : mySecondNumber care este de tip int cu valoare de 12
        // A doua : myThirdNumber care este de tip int cu o valoare de 6
        // Creaza o variabila myLastOne si aceasta are valoarea cu 1000 mai putin decat myTotal si e tip int


    }
}
