public class NumberToWords {
    public static void main(String[] args) {
        numberToWords(123);
    }

    public static void numberToWords(int number){
        if (number<0)
            System.out.println("Invalid Value");
        else{
            int digitReverse = getDigitCount(reverse(number));
            if(getDigitCount(number) > digitReverse){
                int dif = getDigitCount(number) - digitReverse;
                int reverseNumber = reverse(number);
                while (reverseNumber != 0){
                    if(reverseNumber%10 == 1){
                        System.out.println("One");
                    }
                    if(reverseNumber%10 == 2){
                        System.out.println("Two");
                    }
                    if(reverseNumber%10 == 3){
                        System.out.println("Three");
                    }
                    if(reverseNumber%10 == 4){
                        System.out.println("Four");
                    }
                    if(reverseNumber%10 == 5){
                        System.out.println("Five");
                    }
                    if(reverseNumber%10 == 6){
                        System.out.println("Six");
                    }
                    if(reverseNumber%10 == 7){
                        System.out.println("Seven");
                    }
                    if(reverseNumber%10 == 8){
                        System.out.println("Eight");
                    }
                    if(reverseNumber%10 == 9){
                        System.out.println("Nine");
                    }
                    reverseNumber = reverseNumber/10;
                }
                for(int i = 1; i< dif+1; i++){
                    System.out.println("Zero");
                }
            }
            else {
                int reverseNumber = reverse(number);
                while(reverseNumber != 0){
                    if(reverseNumber%10 == 1){
                        System.out.println("One");
                    }
                    if(reverseNumber%10 == 2){
                        System.out.println("Two");
                    }
                    if(reverseNumber%10 == 3){
                        System.out.println("Three");
                    }
                    if(reverseNumber%10 == 4){
                        System.out.println("Four");
                    }
                    if(reverseNumber%10 == 5){
                        System.out.println("Five");
                    }
                    if(reverseNumber%10 == 6){
                        System.out.println("Six");
                    }
                    if(reverseNumber%10 == 7){
                        System.out.println("Seven");
                    }
                    if(reverseNumber%10 == 8){
                        System.out.println("Eight");
                    }
                    if(reverseNumber%10 == 9){
                        System.out.println("Nine");
                    }
                    reverseNumber = reverseNumber/10;
                }
            }
        }
    }
    public static int reverse(int number){
        int nr = getDigitCount(number), reversee = 0, copy = number;
        while (nr != 0){
            reversee = reversee*10 + copy%10;
            copy = copy / 10;
            nr--;
        }
        return reversee;
    }
    public static int getDigitCount(int number){
        int nr=0,copy = number;
        if(number<0)
            return -1;
        else {
            while (copy!=0){
                nr++;
                copy = copy/10;
            }
            return nr;
        }
    }
}
