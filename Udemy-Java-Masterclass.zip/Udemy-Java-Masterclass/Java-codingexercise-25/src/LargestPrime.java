public class LargestPrime {
    public static void main(String[] args) {
        System.out.println(getLargestPrime(45));
    }
    public static int getLargestPrime(int number){
        int maxim = 1;
        if(number<2) {
            return -1;
        }
        else {
            for(int i=2; i<number+1; i++){
                int ok = 0, copy = number;
                if(number%i == 0){
                    while (copy%i == 0){
                        copy = copy/i;
                    }
                    if(copy != 0)
                        number = copy;
                    ok=1;
                }
                if ( ok == 1)
                    maxim = i;
            }
        }
        return maxim;
    }
}
