import java.util.Scanner;
import java.util.*;

public class InputCalculator {
    public static void main(String[] args) {
        inputThenPrintSumAndAverage();
    }
    public static void inputThenPrintSumAndAverage(){
        int sumInt = 0, countInt=0, max= Integer.MAX_VALUE, ok=0;
        long average = 0, sumLong=0, countLong =0;
        Scanner scanner = new Scanner(System.in);
        while (true){
            boolean isInt = scanner.hasNextInt();
            if(isInt){
                int intValue = scanner.nextInt();
                if( intValue < max) {
                    sumInt = sumInt + intValue;
                    countInt++;
                    ok++;
                }
                else{
                    sumLong = sumLong + intValue;
                    countLong++;
                    ok++;
                }
            }
            else{
                break;
            }
            scanner.nextLine();
        }
        scanner.close();
        if(countLong==0 && ok!=0) {
            int fractie = sumInt%countInt;
            average = sumInt / countInt;
            if(fractie > average/2 && average > 0)
                average++;
            if(fractie <average/2 && average < 0)
                average++;
        }
        if(countLong!=0 && ok!=0){
            average = sumInt / countInt + sumLong / countLong;
        }
        System.out.println("SUM = " + sumInt + " AVG = " + average);
    }
}
