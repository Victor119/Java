public class LastDigitChecker {
    public static void main(String[] args) {
        System.out.println(hasSameLastDigit(13,23,40));
    }

    public static boolean hasSameLastDigit(int number_1,int number_2,int number_3){
        if( number_1 < 10 || number_1 >1000 || number_2 < 10 || number_2 >1000 || number_3<10 || number_3>1000)
            return false;
        else {
            if((number_1%10 == number_2%10) || (number_1%10 == number_3%10) || (number_2%10 == number_3%10))
                return true;
            else
                return false;
        }
    }
    public static boolean isValid(int number){
        if(number>9 && number<1001)
            return true;
        else
            return false;
    }
}
