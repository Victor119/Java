public class FirstLastDigitSum {
    public static void main(String[] args) {
        System.out.println(sumFirstAndLastDigit(134));
    }
    public static int sumFirstAndLastDigit(int number){
        int duplicate = number,first =0, last = duplicate%10;
        if(number < 0)
            return -1;
        while ( duplicate > 9){
            duplicate = duplicate/10;
        }
        first = duplicate;
        return first + last;
    }
}
